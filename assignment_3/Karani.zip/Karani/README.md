module load tools/mpich2-1.5-gcc
python run.py matrix_multiply.c cluster -l nodes=1:ppn=4
