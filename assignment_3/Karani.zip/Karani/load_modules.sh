#!/bin/bash

module load tools/mpich2-1.5-gcc
