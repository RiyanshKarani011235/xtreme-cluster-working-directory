module load tools/mpich2-1.5-gcc

python run.py 1D_partitioning_with_n_processes.c cluster -l nodes=1:ppn=4

python run.py 1D_partitioning_with_less_than_n_processes.c cluster -l nodes=2:ppn=4